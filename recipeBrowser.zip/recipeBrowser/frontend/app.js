//Keep track of which html file is currently being viewed
let currentPage = window.location.pathname.split('/').pop();


//Button to other html pages
if (currentPage !== 'index.html') {
    //allows home button functionality
    let homeBtn = document.getElementById('home');
    homeBtn.addEventListener('click', function() {
        window.location.href = 'index.html';
    });
    homeBtn.addEventListener('mouseout', function() {
        homeBtn.style.backgroundColor = '';
    });
}
else{
    //must be on index.html
    let breadBtn = document.getElementById('bread');
    breadBtn.addEventListener('click', function() {
        window.location.href = 'bread.html';
    });
    breadBtn.addEventListener('mouseout', function() {
        breadBtn.style.backgroundColor = '';
    });
}

//THE COMPLICTED CODE TO FILL IN THE INGREDIENTS TABLE
//BE WEARY THIS WAS MADE WHEN THE PROGRAMMER WAS ON A SUGAR HIGH AT 2AM
//PREPARE FOR A SPAGHETTI NOODLE MESS HEAP OF CODE THAT BARELY WORKS

//PS, the list is hardcoded on a JSON file, you can adjust it to see different results
if(currentPage === 'bread.html')
{
    // Get the table body element from the html first
    const tableBody = document.getElementById('ingredients-table');
    // Fetch the JSON file
    fetch('ingredients.json')
        .then(response => response.json())
        .then(data => {
            // Loop through each ingredient in the JSON data
            data.ingredients.forEach(ingredient => {
                // Create a new table row
                const row = document.createElement('tr');
                // Create a new table cell for the ingredient name
                const nameCell = document.createElement('td');
                nameCell.textContent = ingredient.name;
                row.appendChild(nameCell);
                // Create a new table cell for the ingredient quantity
                const quantityCell = document.createElement('td');
                quantityCell.textContent = ingredient.quantity;
                row.appendChild(quantityCell);
                // Append the row to the table body
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching ingredients:', error));
}