//Keep track of which html file is currently being viewed
let currentPage = window.location.pathname.split('/').pop();

//Defining ingredient requirments for each recipe
let breadArray = ['Flour', 'Water', 'Yeast', 'Salt'];
let cakeArray = ['Flour', 'Sugar', 'Eggs', 'Butter', 'Milk', 'Baking Powder'];
let cookieArray = ['Flour', 'Sugar', 'Butter', 'Chocolate Chips'];
let donutArray = ['Flour', 'Sugar', 'Yeast', 'Milk', 'Eggs', 'Olive Oil'];
let pancakeArray = ['Flour', 'Milk', 'Eggs', 'Sugar', 'Baking Powder'];

//Button to other html pages
if (currentPage !== 'index.html') {
    //allows home button functionality
    let homeBtn = document.getElementById('home');
    homeBtn.addEventListener('click', function() {
        window.location.href = 'index.html';
    });
    homeBtn.addEventListener('mouseout', function() {
        homeBtn.style.backgroundColor = '';
    });
}
else{
    //must be on index.html so initalising the buttons
    let breadBtn = document.getElementById('bread');
    let cakeBtn = document.getElementById('cake');
    let cookieBtn = document.getElementById('cookie');
    let donutBtn = document.getElementById('donut');
    let pancakeBtn = document.getElementById('pancake');
    
    //Clcking
    breadBtn.addEventListener('click', function() {
        window.location.href = 'bread.html';
    });
    cakeBtn.addEventListener('click', function() {
        window.location.href = 'cake.html';
    });
    cookieBtn.addEventListener('click', function() {
        window.location.href = 'cookie.html';
    });
    donutBtn.addEventListener('click', function() {
        window.location.href = 'donut.html';
    });
    pancakeBtn.addEventListener('click', function() {
        window.location.href = 'pancake.html';
    });
}

//THE COMPLICTED CODE TO FILL IN THE INGREDIENTS TABLE
//BE WEARY THIS WAS MADE WHEN THE PROGRAMMER WAS ON A SUGAR HIGH AT 2AM
//PREPARE FOR A SPAGHETTI NOODLE MESS HEAP OF CODE THAT BARELY WORKS

//PS, the list is hardcoded on a JSON file, you can adjust it to see different results
//Fetch the JSON file
/*
fetch('ingredients.JSON')
    .then(response => response.json())
    .then(data => {
        //Data acquired from the JSON file
        const ingredients = data.ingredients;
        const name = ingredients.map(ingredient => ingredient.name);
        const quantity = ingredients.map(ingredient => ingredient.quantity);
        const units = ingredients.map(ingredient => ingredient.unit || ''); // Default to empty string if unit is not provided
        //Check which page is being viewed
        if (currentPage === 'bread.html') {
            //Use the bread ingredients array
            const breadTable = document.getElementById('table');
            breadArray.forEach(ingredient => {
                const row = breadTable.insertRow();
                const cell1 = row.insertCell(0);
                const cell2 = row.insertCell(1);
                cell1.textContent = ingredient;
                cell2.textContent = 'Required'; // Placeholder text
            });
            
        }
    }) 
    .catch(error => console.error('Error fetching ingredients:', error));
    */