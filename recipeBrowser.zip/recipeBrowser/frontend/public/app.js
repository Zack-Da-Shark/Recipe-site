console.log("AM AWAKE"); // Debugging line to check if the script is running


//Keep track of which html file is currently being viewed
let currentPage = window.location.pathname.split('/').pop();

//Defining ingredient requirments for each recipe
const breadArray = ['Flour', 'Water', 'Yeast', 'Salt'];
const cakeArray = ['Flour', 'Sugar', 'Eggs', 'Butter', 'Milk', 'Baking Powder'];
const cookieArray = ['Flour', 'Sugar', 'Butter', 'Chocolate Chips'];
const donutArray = ['Flour', 'Sugar', 'Yeast', 'Milk', 'Eggs', 'Olive Oil'];
const pancakeArray = ['Flour', 'Milk', 'Eggs', 'Sugar', 'Baking Powder'];

//Now for the appropriate amouont of ingredients
//bread takjes 500 grams of flour however, we have 5000 grams in the JSON file
//So if there is enough, it will be green, otherwise it will be red
let breadIngredients = {
    Water: 1000,
    Salt: 5,
    Flour: 500,
    Yeast: 10,
};

//Cake should fail because it needs 3 eggs, but we only have 2
let cakeIngredients = {
    Flour: 500,
    Sugar: 300,
    Eggs: 3,
    Butter: 200,
    Milk: 200,
    "Baking Powder": 10
};
let cookieIngredients = {
    Flour: 300,
    Sugar: 200,
    Butter: 150,
    "Chocolate Chips": 100
};
let donutIngredients = {
    Flour: 400,
    Sugar: 200,
    Yeast: 10,
    Milk: 200,
    Eggs: 2,
    "Olive Oil": 50
};
let pancakeIngredients = {
    Flour: 200,
    Milk: 300,
    Eggs: 2,
    Sugar: 50,
    "Baking Powder": 10
};


//Button to other html pages
if (currentPage !== 'main.html') {
    //allows home button functionality
    let homeBtn = document.getElementById('home');
    homeBtn.addEventListener('click', function() {
        window.location.href = 'main.html';
    });
    homeBtn.addEventListener('mouseout', function() {
        homeBtn.style.backgroundColor = '';
    });
}
else{
    //must be on index.html so initalising the buttons
    let breadBtn = document.getElementById('bread');
    let cakeBtn = document.getElementById('cake');
    let cookieBtn = document.getElementById('cookie');
    let donutBtn = document.getElementById('donut');
    let pancakeBtn = document.getElementById('pancake');
    
    //Clcking
    breadBtn.addEventListener('click', function() {
        window.location.href = 'bread.html';
    });
    cakeBtn.addEventListener('click', function() {
        window.location.href = 'cake.html';
    });
    cookieBtn.addEventListener('click', function() {
        window.location.href = 'cookie.html';
    });
    donutBtn.addEventListener('click', function() {
        window.location.href = 'donut.html';
    });
    pancakeBtn.addEventListener('click', function() {
        window.location.href = 'pancake.html';
    });
}

//THE COMPLICTED CODE TO FILL IN THE INGREDIENTS TABLE
//BE WEARY THIS WAS MADE WHEN THE PROGRAMMER WAS ON A SUGAR HIGH AT 2AM
//PREPARE FOR A SPAGHETTI NOODLE MESS HEAP OF CODE THAT BARELY WORKS

//PS, the list is hardcoded on a JSON file, you can adjust it to see different results
//Fetch the JSON file

fetch('/ingredients.JSON')
    .then(response => response.json())
    .then(data => {
        console.log("Data fetched successfully"); // Debugging line to check if data is fetched
        //Data acquired from the JSON file
        let ingredients = data; // Assuming the JSON file is an array of ingredient objects
        console.log("Ingredients:", ingredients); // Debugging line to check the ingredients data
        //Check which page is being viewed
        if (currentPage === 'bread.html')
        { //THIS IS THE BREAD PAGE
            //aquire the fridge button
            const fridgeButton = document.getElementById('fridge');
            //if button gets clicked, it will check the fridge
            fridgeButton.addEventListener('click', () => {
                //Display a message in the console
                console.log("Checking the fridge for ingredients...");
                //Display a message on the page
                showPopup('Fridge checked! Ingredients are displayed in the table.');
                //Disable the button permanently
                fridgeButton.disabled = true;
                fridgeButton.style.backgroundColor = 'grey'; // Change color to indicate it's disabled
                //Use the bread ingredients array for approppriate ingredients
                try
                {
                    const breadTable = document.getElementById('ingredients-table');
                    breadArray.forEach(ingredient => {
                        //checks if the ingredient exists in the JSON data
                        const ingredientData = ingredients.find(item => item.name === ingredient);
                        if (ingredientData)
                        {
                            const row = breadTable.insertRow();
                            const cell1 = row.insertCell(0);
                            const cell2 = row.insertCell(1);
                            cell1.textContent = ingredientData.name;
                            cell2.textContent = `${breadIngredients[ingredient]} ${ingredientData.unit}`;
                            if (ingredientData.quantity >= breadIngredients[ingredient])
                            {
                                cell2.style.color = 'green'; // Enough ingredients
                                //also needs to add a tick or check image after the string
                                cell2.innerHTML += ' &#10003;'; // Adding a check mark
                            }
                            else
                            {
                                cell2.style.color = 'red'; // Not enough ingredients
                                //also needs to add a cross or x image after the string
                                cell2.innerHTML += ' &#10060;'; // Adding a cross mark
                                cell2.textContent += ` (Need ${breadIngredients[ingredient] - ingredientData.quantity} more)`;
                            }
                        }
                        else
                            console.error(`Ingredient ${ingredient} not found in JSON data`);
                });
            }
            catch (error)
            {
                console.error('Error populating bread ingredients table:', error);
            }
        });
        }
        else if (currentPage === 'cake.html')
        { //THIS IS THE CAKE PAGE
            const fridgeButton = document.getElementById('fridge');
            fridgeButton.addEventListener('click', () => {
                console.log("Checking the fridge for ingredients...");
                showPopup('Fridge checked! Ingredients are displayed in the table.');
                fridgeButton.disabled = true;
                fridgeButton.style.backgroundColor = 'grey'; // Change color to indicate it's disabled
                try
                {
                    const cakeTable = document.getElementById('ingredients-table');
                    cakeArray.forEach(ingredient => {
                        const ingredientData = ingredients.find(item => item.name === ingredient);
                        if (ingredientData)
                        {
                            const row = cakeTable.insertRow();
                            const cell1 = row.insertCell(0);
                            const cell2 = row.insertCell(1);
                            cell1.textContent = ingredientData.name;
                            cell2.textContent = `${cakeIngredients[ingredient]} ${ingredientData.unit}`;
                            if (ingredientData.quantity >= cakeIngredients[ingredient])
                            {
                                cell2.style.color = 'green'; // Enough ingredients
                                cell2.innerHTML += ' &#10003;'; // Adding a check mark
                            }
                            else
                            {
                                cell2.style.color = 'red'; // Not enough ingredients
                                cell2.innerHTML += ' &#10060;'; // Adding a cross mark
                                cell2.textContent += ` (Need ${cakeIngredients[ingredient] - ingredientData.quantity} more)`;
                            }
                        }
                        else
                            console.error(`Ingredient ${ingredient} not found in JSON data`);
                    });
                }
                catch (error)
                {
                    console.error('Error populating cake ingredients table:', error);
                }
            });
        }
        else if (currentPage === 'cookie.html')
        { //THIS IS THE COOKIE PAGE
            const fridgeButton = document.getElementById('fridge');
            fridgeButton.addEventListener('click', () => {
                console.log("Checking the fridge for ingredients...");
                showPopup('Fridge checked! Ingredients are displayed in the table.');
                fridgeButton.disabled = true;
                fridgeButton.style.backgroundColor = 'grey';
                try
                {
                    const cookieTable = document.getElementById('ingredients-table');
                    cookieArray.forEach(ingredient => {
                        const ingredientData = ingredients.find(item => item.name === ingredient);
                        if (ingredientData)
                        {
                            const row = cookieTable.insertRow();
                            const cell1 = row.insertCell(0);
                            const cell2 = row.insertCell(1);
                            cell1.textContent = ingredientData.name;
                            cell2.textContent = `${cookieIngredients[ingredient]} ${ingredientData.unit}`;
                            if (ingredientData.quantity >= cookieIngredients[ingredient])
                            {
                                cell2.style.color = 'green'; // Enough ingredients
                                cell2.innerHTML += ' &#10003;'; // Adding a check mark
                            }
                            else
                            {
                                cell2.style.color = 'red';
                                cell2.innerHTML += ' &#10060;'; // Adding a cross mark
                                cell2.textContent += ` (Need ${cookieIngredients[ingredient] - ingredientData.quantity} more)`;
                            }
                        }
                        else
                            console.error(`Ingredient ${ingredient} not found in JSON data`);
                    });
                }
                catch (error)
                {
                    console.error('Error populating cookie ingredients table:', error);
                }
            });
        }
        else if (currentPage === 'donut.html')
        { //THIS IS THE DONUT PAGE
            const fridgeButton = document.getElementById('fridge');
            fridgeButton.addEventListener('click', () => {
                console.log("Checking the fridge for ingredients...");
                showPopup('Fridge checked! Ingredients are displayed in the table.');
                fridgeButton.disabled = true;
                fridgeButton.style.backgroundColor = 'grey';
                try
                {
                    const donutTable = document.getElementById('ingredients-table');
                    donutArray.forEach(ingredient => {
                        const ingredientData = ingredients.find(item => item.name === ingredient);
                        if (ingredientData)
                        {
                            const row = donutTable.insertRow();
                            const cell1 = row.insertCell(0);
                            const cell2 = row.insertCell(1);
                            cell1.textContent = ingredientData.name;
                            cell2.textContent = `${donutIngredients[ingredient]} ${ingredientData.unit}`;
                            if (ingredientData.quantity >= donutIngredients[ingredient])
                            {
                                cell2.style.color = 'green';
                                cell2.innerHTML += ' &#10003;'; // Adding a check mark
                            }
                            else
                            {
                                cell2.style.color = 'red';  
                                cell2.innerHTML += ' &#10060;'; // Adding a cross mark
                                cell2.textContent += ` (Need ${donutIngredients[ingredient] - ingredientData.quantity} more)`;
                            }
                        }
                        else
                            console.error(`Ingredient ${ingredient} not found in JSON data`);
                    });
                }
                catch (error)
                {
                    console.error('Error populating donut ingredients table:', error);
                }
            });
        }
        else if (currentPage === 'pancake.html')
        { //THIS IS THE PANCAKE PAGE
            const fridgeButton = document.getElementById('fridge');
            fridgeButton.addEventListener('click', () => {
                console.log("Checking the fridge for ingredients...");
                showPopup('Fridge checked! Ingredients are displayed in the table.');
                fridgeButton.disabled = true;
                fridgeButton.style.backgroundColor = 'grey';
                try
                {
                    const pancakeTable = document.getElementById('ingredients-table');
                    pancakeArray.forEach(ingredient => {
                        const ingredientData = ingredients.find(item => item.name === ingredient);
                        if (ingredientData)
                        {
                            const row = pancakeTable.insertRow();
                            const cell1 = row.insertCell(0);
                            const cell2 = row.insertCell(1);
                            cell1.textContent = ingredientData.name;
                            cell2.textContent = `${pancakeIngredients[ingredient]} ${ingredientData.unit}`;
                            if (ingredientData.quantity >= pancakeIngredients[ingredient])
                            {
                                cell2.style.color = 'green'; // Enough ingredients
                                cell2.innerHTML += ' &#10003;'; // Adding a check mark
                            }
                            else
                            {
                                cell2.style.color = 'red';
                                cell2.innerHTML += ' &#10060;'; // Adding a cross mark
                                cell2.textContent += ` (Need ${pancakeIngredients[ingredient] - ingredientData.quantity} more)`;
                            }   
                        }
                        else
                            console.error(`Ingredient ${ingredient} not found in JSON data`);
                    });
                }
                catch (error)
                {
                    console.error('Error populating pancake ingredients table:', error);
                }
            });
        }
    })
    .catch(error => console.error('Error fetching ingredients:', error));
    //IT WORKS THROUGH THE POWER OF MADONNA AND SUGAR
function showPopup(message)
{
  const popup = document.getElementById('popup');
  popup.textContent = message;
  popup.style.display = 'block';
  setTimeout(() => {
    popup.style.display = 'none';
  }, 2000); // Popup disappears after 2 seconds
}
//This function is used to show a popup message when the fridge button is clicked
//got this code from another project of mine