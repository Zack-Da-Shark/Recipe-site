const cors = require('cors');
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const fs = require('fs');

//Boiler plate code for express server
app.use(express.json());
app.use(cors());

//acquring ingredients from JSON file
app.use(express.static(path.join(__dirname, '../frontend/public')));
app.get('/ingredients', (req, res) => {
  fs.readFile(path.join(__dirname, 'ingredients.json'), 'utf8', (err, data) => {
    if (err) {
        return res.status(500).send('Error reading ingredients file');
    }
    res.json(JSON.parse(data));
    });
});

//Server activatpion message
app.listen(3000, () => {
  console.log('Server running on port 3000');
  console.log('Open http://localhost:3000/main.html in your browser');
});