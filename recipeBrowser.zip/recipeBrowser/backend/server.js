const cors = require('cors');
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
//Boiler plate code for express server
app.use(cors());